import cowsay

def main():
    print("I try to understand wtf is going here")
    cowsay.tux('LOOOOOOOOOOL')


if __name__ == '__main__':
    main()

